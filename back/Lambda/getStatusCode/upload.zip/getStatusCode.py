import boto3
from boto3.dynamodb.conditions import Key, Attr
#import logging
import json
import simplejson
#import datetime
#from decimal import Decimal

# DynamoDB
dynamodb = boto3.resource('dynamodb')
_sstatus_ = dynamodb.Table('S-Status')

_code_ = 200
_limit_ = 10
def lambda_handler(event, context):
# tableをスキャン
  _scan_ = _sstatus_.scan(
    FilterExpression=Attr('scode').eq(_code_),
    Limit=_limit_
  )['Items']

  _list_ = len(_scan_)

  _dlist_ = []
  _slist_ = []
  for i in range(0,_list_):
    _result_ = _scan_[i]
    _dlist_.append(_result_['date'])
    _slist_.append(_result_['scode'])

  _alist_ = [json.dumps(_dlist_), simplejson.dumps(_slist_)]
  print(_alist_)
